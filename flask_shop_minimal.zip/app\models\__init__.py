# Импорт моделей для удобного доступа
from app.models.user import User
from app.models.product import Category, Product
from app.models.blog import BlogPost, BlogCategory
from app.models.order import Order, OrderItem
from app.models.settings import SocialLink, SiteSettings